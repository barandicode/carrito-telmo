Vue.component('producto', {
    props: ['nombre', 'foto', 'precio'],
    data() {
        return {
            cantidad: 1
        };
    },
    template: `
        <div class="producto">
            <h3>{{ nombre }}</h3>
            <img :src="foto" alt="Foto del producto" style="max-width: 100px;">
            <p>Precio: ${{ precio }}</p>
            <input type="number" v-model="cantidad" min="1">
            <button @click="agregarAlCarrito">Añadir al carrito</button>
        </div>
    `,
    methods: {
        agregarAlCarrito() {
            this.$emit('agregar-al-carrito', {
                nombre: this.nombre,
                precio: this.precio,
                cantidad: this.cantidad
            });
        }
    }
});

new Vue({
    el: '#app',
    data: {
        carrito: []
    },
    methods: {
        agregarAlCarrito(producto) {
            this.carrito.push(producto);
            console.log('Producto añadido al carrito:', producto);
        }
    },
    template: `
        <div>
            <h1>Carrito de Compras</h1>
            <producto
                v-for="producto in productos"
                :key="producto.nombre"
                :nombre="producto.nombre"
                :foto="producto.foto"
                :precio="producto.precio"
                @agregar-al-carrito="agregarAlCarrito"
            ></producto>
            <div>
                <h2>Carrito</h2>
                <ul>
                    <li v-for="(producto, index) in carrito" :key="index">
                        {{ producto.nombre }} - Cantidad: {{ producto.cantidad }}
                    </li>
                </ul>
            </div>
        </div>
    `,
    computed: {
        productos() {
            return [
                { nombre: 'Producto 1', foto: 'imagen1.jpg', precio: 10 },
                { nombre: 'Producto 2', foto: 'imagen2.jpg', precio: 20 },
                // Agrega más productos según sea necesario
            ];
        }
    }
});
